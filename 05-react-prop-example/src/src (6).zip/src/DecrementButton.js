function DecrementButton(props){
    return(
        <button className = "btn" onClick = {props.referenceMethod}> -1 </button>
    );
}

export default DecrementButton;