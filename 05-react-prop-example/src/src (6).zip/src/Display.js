function Display(props){
    return(
        <div>{props.counterValue}</div>
    );
    
}
export default Display;