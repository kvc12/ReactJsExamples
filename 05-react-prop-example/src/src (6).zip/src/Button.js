function Button(props){
    return(
        <button className = "btn" onClick = {props.referenceMethod}>+1</button>
    );
}

export default Button;