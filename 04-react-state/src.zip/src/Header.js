function Header(){
    //this function return 
    return (
    <div className="jumbotron">
      <h1 className="display-4">React Props Project</h1>
      <hr/>
      <p className="my-4">
      The state is an instance of React Component Class can be defined as an object of a set of observable properties that control the behavior of the component. In other words, the State of a component is an object that holds some information that may
       change over the lifetime of the component.
      </p>
      </div> 
    );
}
export default Header;