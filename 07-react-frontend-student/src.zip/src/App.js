import Header from './component/pages/Header'
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'
import { Home } from './component/pages/Home';
import { DeleteStudent } from './component/student/DeleteStudent';
import AddStudent from './component/student/AddStudent';
import { ViewStudent } from './component/student/viewStudent';
function App() {
  return (
    <div className="container">
      <Router>
        <Header />
        <Switch>
          <Route exact path='/' component={Home} />
          <Route exact path='/students' component={Home} />
          <Route exact path='/students/add' component={AddStudent} />
          <Route exact path='/students/view/:id' component={ViewStudent} />

          <Route exact path='/students/delete/:id' component={DeleteStudent} />
        </Switch>
      </Router>
    </div>
  );
}

export default App;
