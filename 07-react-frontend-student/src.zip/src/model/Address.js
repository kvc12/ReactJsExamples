export class Address {

    addressId = "";
    city = "";
    state = "";
    pin = "";

}