import { Address } from "./Address"
export class Student {
    studentId = "";
    studentName = "";
    studentScore = "";
    address = new Address();
}