import { Link } from "react-router-dom";

function Header() {
    return (
        <div className="jumbotron jumbotron-fluid">
            <h1 className="display-4">React Frontend Project</h1>
            <hr />
            <p className="my-4">
                This project going to perform the CRUD operation on Student by interacting applications.
                We are going to use to connect frontend to backend axios module by which we will be able to call the REST endpoints.
            </p>
            <Link className="btn btn-primary" to={`/students/add`}>Add Student</Link>
        </div>
    );
}
export default Header;